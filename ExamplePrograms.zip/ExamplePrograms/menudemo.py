"""
File: menudemo.py
"""

from breezypythongui import EasyFrame

class MenuDemo(EasyFrame):
    """Displays the name of the selected menu item."""
    
    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, "Menu Demo")
        
        # Add the menu bar for the two menus
        menuBar = self.addMenuBar(row = 0, column = 0, columnspan = 2)
        
        # Add the File menu
        fileMenu = menuBar.addMenu("File")
        
        # Add the command options for the File menu
        fileMenu.addMenuItem("New",  self.newSelected)
        fileMenu.addMenuItem("Open", self.openSelected)
        fileMenu.addMenuItem("Save", self.saveSelected)
        
        # Add the Edit menu
        editMenu = menuBar.addMenu("Edit")
        
        # Add the command options for the Edit menu
        editMenu.addMenuItem("Copy",  self.copySelected)
        editMenu.addMenuItem("Cut",   self.cutSelected)
        editMenu.addMenuItem("Paste", self.pasteSelected)
        
        # Output field for the results
        self.output = self.addTextField("", row = 1, column = 0)

    # Event handlers for menu commands

    def newSelected(self):
        self.output.setText("New")
        
    def openSelected(self):
        self.output.setText("Open")

    def saveSelected(self):
        self.output.setText("Save")

    def copySelected(self):
        self.output.setText("Copy")

    def cutSelected(self):
        self.output.setText("Cut")

    def pasteSelected(self):
        self.output.setText("Paste")
        

# Instantiate and pop up the window."""
MenuDemo().mainloop()
