"""
File: canvasdemo2.py

Demostrates the capabilities of canvases.
"""

from breezypythongui import EasyFrame, EasyCanvas

class CanvasDemo(EasyFrame):
    """Displays two canvases, one for shapes and the other
    for points.  Responds to mouse events."""

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "Canvas Demo")

        # Labels
        self.addLabel(text = "Canvas 1", row = 0, column = 0)
        self.addLabel(text = "Canvas 2", row = 0, column = 1)

        # Canvasses
        self.leftCanvas = self.addCanvas(canvas = LeftCanvas(self),
                                         row = 1, column = 0)
        rightCanvas = self.addCanvas(canvas = RightCanvas(self),
                                     row = 1, column = 1)
        
        # The command button
        self.button = self.addButton(text = "Clear Shapes",
                                     row = 2, column = 0,
                                     columnspan = 2,
                                     command = self.clearAll)

    def clearAll(self):
        """Deletes all shapes from left canvas."""
        self.leftCanvas.clearAll()


class LeftCanvas(EasyCanvas):
    """This canvas supports the drawing of ovals.  The user presses the mouse button
    at one corner and drags to the other corner before releasing."""

    def __init__(self, parent):
        """Background is medium red.  Items drawn are tracked for later erasing."""
        EasyCanvas.__init__(self, parent, background = "#CC0000")
        self.items = list()

    def mousePressed(self, event):
        """Sets the first corner of the oval's bounding rectangle."""
        self.x = event.x
        self.y = event.y

    def mouseReleased(self, event):
        """Sets the second corner of the oval's bounding rectangle.
        Draws an oval filled in blue and saves its id."""
        if self.x != event.x and self.y != event.y:
            item = self.drawOval(self.x, self.y,
                                 event.x, event.y, fill = "#0000CC")
            self.items.append(item)

    def clearAll(self):
        """Deletes all ovals from left canvas."""
        for item in self._items:
            self.deleteItem(item)
        self.items = list()


class RightCanvas(EasyCanvas):
    """Displays the coordinates of the point where the mouse is pressed."""

    def __init__(self, parent):
        """Background is medium blue."""
        EasyCanvas.__init__(self, parent, background = "#0000CC") 

    def mousePressed(self, event):
        """Draws the coordinates of the mouse press in white."""
        self.drawText("(" + str(event.x) + "," + str(event.y) + ")",
                      event.x, event.y, fill = "white")


# Instantiate and pop up the window."""
CanvasDemo().mainloop()
