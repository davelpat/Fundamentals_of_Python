"""
File: taxcodedemo2.py

A dialog-based tax calculator.

Computes and prints the total tax, given the income,
number of dependents, exemption amount (all inputs), and
a flat tax rate of 15%.
"""

from breezypythongui import PrompterBox, MessageBox

title = "Tax Calculator"

# Prompt the user for three successive inputs
income = float(PrompterBox.prompt(\
    title,
    "Please enter your income:",
    "0.0"))
numDependents = int(PrompterBox.prompt(\
    title,
    "Please enter the number of dependents:",
    "0"))
exemptionAmount = float(PrompterBox.prompt(\
    title,
    "Please enter the exemption amount:",
    "0.0"))

# Compute the tax
tax = (income - numDependents * exemptionAmount) * .15

# Output the tax
MessageBox.message(title,
                   "Your total tax is $%0.2f" % tax)

