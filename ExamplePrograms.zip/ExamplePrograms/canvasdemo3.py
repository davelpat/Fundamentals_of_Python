"""
File: canvasdemo3.py

Demostrates the capabilities of canvases.
"""

from breezypythongui import EasyFrame, EasyCanvas

class CanvasDemo(EasyFrame):
    """Supports freehand drawing with the mouse."""

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "Freehand Drawing")

        # The canvas
        self.canvas = self.addCanvas(canvas = Sketchpad(self),
                                     row = 0, column = 0)
        
        # The command button
        self.button = self.addButton(text = "Clear Shapes",
                                     row = 1, column = 0,
                                     command = self.clearAll)

    def clearAll(self):
        """Deletes all drawings from the canvas."""
        self.canvas.clearAll()


class Sketchpad(EasyCanvas):
    """This canvas supports Supports freehand drawing with the mouse."""

    def __init__(self, parent):
        """Background is gray.  Items drawn are tracked for later erasing."""
        EasyCanvas.__init__(self, parent, background = "gray")
        self.items = list()

    def mousePressed(self, event):
        """Sets the first end point of a line segment."""
        self.x = event.x
        self.y = event.y

    def mouseMoved(self, event):
        """Sets the second end point of a line segment.
        Draws the line segment in blue and saves its id."""
        if self.x != event.x and self.y != event.y:
            item = self.drawLine(self.x, self.y,
                                 event.x, event.y,
                                 width = 3, fill = "#0000CC")
            self.x = event.x
            self.y = event.y
            self.items.append(item)

    def clearAll(self):
        """Deletes all drawings from the canvas."""
        for item in self.items:
            self.deleteItem(item)
        self.items = list()


# Instantiate and pop up the window.
CanvasDemo().mainloop()
