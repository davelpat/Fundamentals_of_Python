"""
File: dialogdemo.py
Author: Kenneth A. Lambert
"""

from breezypythongui import EasyFrame, EasyDialog
from cd import CD

class DialogDemo(EasyFrame):
    """Demonstrates a dialog."""
    
    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, "Dialog Demo")
        self.cd = CD("Let It Be", "The Beatles", 10.00)

        self.outputArea = self.addTextArea(text = str(self.cd),
                                           row = 0, column = 0,
                                           width = 30, height = 4)

        self.addButton(text = "Modify", row = 1, column = 0,
                       command = self.modify)
        
    # Event handling method.
    def modify(self):
        """Pops up a dialog to edit the model."""
        dialog = CDDialog(self, self.cd)
        if dialog.modified():
            self.outputArea.setText(str(self.cd))

class CDDialog(EasyDialog):
    """Opens a dialog on a CD object."""

    def __init__(self, parent, cd):
        """Sets up the window."""
        self.cd = cd
        EasyDialog.__init__(self, parent, "CD Dialog")
    
    def body(self, master):
        """Sets up the widgets."""
        self.addLabel(master, text = "Title", row = 0, column = 0)
        self.addLabel(master, text = "Artist", row = 1, column = 0)
        self.addLabel(master, text = "Price", row = 2, column = 0)
        self.titleFld = self.addTextField(master, text = self.cd.title,
                                          row = 0, column = 1)
        self.artistFld = self.addTextField(master, text = self.cd.artist,
                                           row = 1, column = 1)
        self.priceFld = self.addFloatField(master, value = self.cd.price,
                                           row = 2, column = 1)

    def apply(self):
        """Transfers data from the fields to the CD."""
        self.cd.title = self.titleFld.getText()
        self.cd.artist = self.artistFld.getText()
        self.cd.price = self.priceFld.getNumber()
        self.setModified()


if __name__ == "__main__":
    DialogDemo().mainloop()
