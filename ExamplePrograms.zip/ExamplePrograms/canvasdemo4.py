"""
File: canvasdemo4.py

Demostrates the capabilities of canvases.
"""

from breezypythongui import EasyFrame, EasyCanvas
from tkinter import PhotoImage, DISABLED, NORMAL, NW

class CanvasDemo(EasyFrame):
    """Draws or erases an image."""

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "Image on Canvas")

        # The canvas
        self.canvas = self.addCanvas(canvas = ImageCanvas(self),
                                     columnspan = 2,
                                     row = 0, column = 0)
        # The command buttons
        self.drawBtn = self.addButton(text = "Draw",
                                      row = 1, column = 0,
                                      command = self.draw)

        self.eraseBtn = self.addButton(text = "Erase",
                                       row = 1, column = 1,
                                       command = self.erase)

        self.draw()
        

    def draw(self):
        """Draws the image and sets the button states."""
        self.canvas.draw()
        self.drawBtn["state"] = DISABLED
        self.eraseBtn["state"] = NORMAL

    def erase(self):
        """Erases the image and sets the button states."""
        self.canvas.erase()
        self.eraseBtn["state"] = DISABLED
        self.drawBtn["state"] = NORMAL

class ImageCanvas(EasyCanvas):
    """This canvas supports the display of an image."""

    def __init__(self, parent):
        """Background is gray."""
        EasyCanvas.__init__(self, parent, background = "gray")
        self.image = PhotoImage(file = "smokey.gif")

    def draw(self):
        """Draws the image ans tracks it for later erasing."""
        self.item = self.drawImage(self.image, 0, 0, anchor = NW)

    def erase(self):
        """Erases the image."""
        self.delete(self.item)


# Instantiate and pop up the window.
CanvasDemo().mainloop()
