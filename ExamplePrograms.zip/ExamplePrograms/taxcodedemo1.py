"""
File: taxcodedemo1.py

A terminal-based tax calculator.

Computes and prints the total tax, given the income,
number of dependents, exemption amount (all inputs), and
a flat tax rate of 15%.
"""

print("Tax Calculator\n")
income = float(input("Please enter your income: $"))
numDependents = int(input("Please enter the number of dependents: "))
exemptionAmount = float(input("Please enter the exemption amount: $"))
tax = (income - numDependents * exemptionAmount) * .15
print("Your total tax is $%0.2f" % tax)

