"""
File: circlearea2.py
"""

from breezypythongui import EasyFrame
import math

class CircleArea(EasyFrame):
    """Computes the area or the radius of a circle."""

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "Circle Area or Radius")

        # Label and field for the radius
        self.addLabel(text = "Radius",
                      row = 0, column = 0)
        self.radiusField = self.addFloatField(value = 0.0,
                                              row = 1,
                                              column = 0)

        # Label and field for the area
        self.addLabel(text = "Area",
                      row = 0, column = 1)
        self.areaField = self.addFloatField(value = 0.0,
                                            row = 1,
                                            column = 1)

        # Radius to area button
        self.addButton(text = ">>>>",
                       row = 2, column = 0,
                       command = self.computeArea)

        # Radius to area button
        self.addButton(text = "<<<<",
                       row = 2, column = 1,
                       command = self.computeRadius)

    # The event handler method for the area button
    def computeArea(self):
        """Inputs the radius, computes the area,
        and outputs the area."""
        radius = self.radiusField.getNumber()
        area = radius ** 2 * math.pi
        self.areaField.setNumber(area)

    # The event handler method for the radius button
    def computeRadius(self):
        """Inputs the area, computes the radius,
        and outputs the radius."""
        area = self.areaField.getNumber()
        radius = math.sqrt(area / math.pi)
        self.radiusField.setNumber(radius)

#Instantiate and pop up the window.
CircleArea().mainloop()
