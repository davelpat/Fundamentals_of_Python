"""
File: filedialogdemo.py
Author: Kenneth A. Lambert
"""

from breezypythongui import EasyFrame
import tkinter.filedialog

class FileDialogDemo(EasyFrame):
    """Demonstrates a file dialog."""
    
    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, "File Dialog Demo")

        self.outputArea = self.addTextArea("", row = 0, column = 0,
                                           width = 50, height = 15)

        self.addButton(text = "Open", row = 1, column = 0,
                       command = self.openFile)
        
    # Event handling method.
    def openFile(self):
        """Pops up a file dialog, and if a file is opened,
        outputs its text to the text area."""
        filetypes = [("Python files", "*.py"), ("Text files", "*.txt")]
        dialog = tkinter.filedialog.Open(self, filetypes = filetypes)
        fileName = dialog.show()
        if fileName != "":
            file = open(fileName, "r")
            text = file.read()
            self.outputArea["state"] = "normal"
            self.outputArea.setText(text)
            self.outputArea["state"] = "disabled"
            file.close()

if __name__ == "__main__":
    FileDialogDemo().mainloop()
   
