"""
File: paneldemo0.py

Displays several colored panels of varying widths and heights.
"""

from breezypythongui import EasyFrame

class PanelDemo(EasyFrame):

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "Panel Demo",
                           width = 400, height = 400)

        # Add panels to the main frame (4 rows by 3 columns)
        self.addPanel(row = 0, column = 0, background = "red")
        self.addPanel(row = 1, column = 0, background = "green")
        self.addPanel(row = 2, column = 0, background = "blue")
        self.addPanel(row = 3, column = 0, background = "yellow",
                      columnspan = 3)
        self.addPanel(row = 0, column = 1, background = "pink",
                      rowspan = 3)
        panel = self.addPanel(row = 0, column = 2,
                              rowspan = 3)
        # Add nested panels to the rightmost panel
        panel.addPanel(row = 0, column = 0, background = "black")
        panel.addPanel(row = 1, column = 0, background = "gray")

#Instantiate and pop up the window."""
PanelDemo().mainloop()
